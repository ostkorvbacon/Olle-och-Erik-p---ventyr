Programmet består av 1 c fil som kompileras: > gcc -o <exekverbar fil> lab1_2_v2.c -lpthread -lrt

och sedan körs: > ./<exekverbar fil>

